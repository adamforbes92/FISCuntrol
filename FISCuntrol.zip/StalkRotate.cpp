#include "StalkRotate.h"
extern int currentGroup;
extern bool successfulConn;
extern bool successfulConnNoDrop;
extern int maxAttemptsCountModule;
extern int intCurrentModule;
//#define NMODULES 4

void StalkRotate::StalkRotateUp()
{

}

void StalkRotate::StalkRotateDown()
{

}

void StalkRotate::StalkRotateUpHeld()
{

}

void StalkRotate::StalkRotateDownHeld()
{

}
